<?php

return [
    'name'   => 'Notifications',
    'create' => 'New notification',
    'edit'   => 'Edit notification',
    'date_sent'=>'Date Sent',
    'message'=>'Message',
    'type'=>'Type',
    'category'=>'Category',
    'product'=>'Product',
    'all-user'=>'اشعار جماعي',
    'one-user'=>'اشعار مخصص',
    'customers'=>'العميل'
];
