<?php

if (!defined('NOTIFICATION_MODULE_SCREEN_NAME')) {
    define('NOTIFICATION_MODULE_SCREEN_NAME', 'notification');
}
