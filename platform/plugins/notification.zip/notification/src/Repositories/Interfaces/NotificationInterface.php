<?php

namespace Botble\Notification\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface NotificationInterface extends RepositoryInterface
{
}
