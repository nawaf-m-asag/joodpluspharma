<?php

namespace Botble\Notification\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Notification\Repositories\Interfaces\NotificationInterface;

class NotificationCacheDecorator extends CacheAbstractDecorator implements NotificationInterface
{

}
