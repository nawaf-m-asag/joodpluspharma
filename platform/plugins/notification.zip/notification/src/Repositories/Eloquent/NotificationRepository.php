<?php

namespace Botble\Notification\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Notification\Repositories\Interfaces\NotificationInterface;

class NotificationRepository extends RepositoriesAbstract implements NotificationInterface
{
}
