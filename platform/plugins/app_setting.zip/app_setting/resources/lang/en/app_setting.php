<?php

return [
    'name'   => 'App setting',
    'create' => 'New app setting',
    'edit'   => 'Edit app setting',
    'cities' => 'Cities',
    'city'   =>  'City',
    'areas'  => 'Area',
    'area_name'=>'Area Name',
    'city_name'=>'City Name',
    
];
