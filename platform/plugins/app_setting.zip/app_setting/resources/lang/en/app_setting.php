<?php

return [
    'name'   => 'App setting',
    'create' => 'New app setting',
    'edit'   => 'Edit app setting',
    'cities' => 'Cities',
    'city'   =>  'City',
    'areas'  => 'Area',
    'area_name'=>'Area Name',
    'city_name'=>'City Name',
    'app_setting'=>'App Settings Edit',
    'privacy_policy'=>'Privacy Policy',
    'terms_conditions'=>'Terms Conditions',
    'fcm_server_key'=>'Fcm Server Key',
    'contact_us'=>'Contact Us',
    'about_us'=>'About Us',
    'is_time_slots_enabled'=>'Is Time Slots Enabled',
    'delivery_starts_from'=>'Delivery Starts From',
    'allowed_days'=>'Allowed Days',
    'time_slot_config'=>'Time Slot Config',
    'time'=>'Time',
    'times'=>'Times',
    'time_title'=>'Time Title',
    'from_time'=>'From Time',
    'to_time'=>'To Time',
    'last_order_time'=>'Last Order Time',
    'from_time'=>'From Time',
   

];
