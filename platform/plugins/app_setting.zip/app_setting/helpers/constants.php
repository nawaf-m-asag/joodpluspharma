<?php

if (!defined('CITY_MODULE_SCREEN_NAME')) {
    define('CITY_MODULE_SCREEN_NAME', 'city');
}

if (!defined('AREA_MODULE_SCREEN_NAME')) {
    define('AREA_MODULE_SCREEN_NAME', 'area');
}
