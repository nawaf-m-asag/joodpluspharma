<?php

namespace Botble\App_setting\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\App_setting\Repositories\Interfaces\TimeInterface;

class TimeRepository extends RepositoriesAbstract implements TimeInterface
{
}
