<?php

namespace Botble\App_setting\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\App_setting\Repositories\Interfaces\AreaInterface;

class AreaRepository extends RepositoriesAbstract implements AreaInterface
{
}
