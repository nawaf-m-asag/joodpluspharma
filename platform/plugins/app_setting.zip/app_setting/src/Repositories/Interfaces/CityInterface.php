<?php

namespace Botble\App_setting\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface CityInterface extends RepositoryInterface
{
    
}
