<?php

namespace Botble\App_setting\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\App_setting\Repositories\Interfaces\AreaInterface;

class AreaCacheDecorator extends CacheAbstractDecorator implements AreaInterface
{

}
